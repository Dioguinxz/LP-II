package br.org.fundatec.lpII.tfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
