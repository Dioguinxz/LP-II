package br.org.fundatec.lpII.tfinal.controller.response;

import br.org.fundatec.lpII.tfinal.model.Produto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProdutoResponse {
    private Integer id;
    private String nome;
    private Integer preco;
    private String descricao;

    public static ProdutoResponse of(Produto produto) {
        return ProdutoResponse.builder()
                .id(produto.getId())
                .nome(produto.getNome())
                    .preco(produto.getValor())
                .descricao(produto.getDescricao())
                .build();

    }

}
