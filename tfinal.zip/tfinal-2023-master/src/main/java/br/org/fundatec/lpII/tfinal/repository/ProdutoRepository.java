package br.org.fundatec.lpII.tfinal.repository;

import br.org.fundatec.lpII.tfinal.model.Cliente;
import br.org.fundatec.lpII.tfinal.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {

    @Query(value = "select p from Produto p where p.nome like :nome")
    List<Produto> buscarProdutoPeloNome(String nome);

    // spring name convention (magic names)
    List<Produto> findAllByNomeIsLike(String nome);

    @Query(value = "update Produto set nome = :nome where id = :id")
    @Modifying
    void editarProdutoPeloNome(String id, String nome);
}