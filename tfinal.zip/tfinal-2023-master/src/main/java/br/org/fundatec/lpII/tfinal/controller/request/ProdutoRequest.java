package br.org.fundatec.lpII.tfinal.controller.request;

import br.org.fundatec.lpII.tfinal.model.Cliente;
import br.org.fundatec.lpII.tfinal.model.Produto;
import lombok.Data;

import java.util.List;

@Data
public class ProdutoRequest {
    private String nome;
    private Integer preco;
    private String descricao;

    public Produto toModel() {
        return Produto.builder()
                .nome(nome)
                .valor(preco)
                .descricao(descricao)
                .build();
    }
}
