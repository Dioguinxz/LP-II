package br.org.fundatec.lpII.tfinal.controller.request;

import lombok.Data;

@Data
public class EditarAtendimentoRequest {
    private Integer valorConsulta;
}
