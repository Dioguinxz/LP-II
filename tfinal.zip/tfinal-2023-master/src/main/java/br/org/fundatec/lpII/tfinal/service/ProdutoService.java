package br.org.fundatec.lpII.tfinal.service;

import br.org.fundatec.lpII.tfinal.model.Cliente;
import br.org.fundatec.lpII.tfinal.model.Produto;
import br.org.fundatec.lpII.tfinal.repository.ClienteRepository;
import br.org.fundatec.lpII.tfinal.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {
    private final ProdutoRepository repository;

    public ProdutoService(ProdutoRepository repository) {
        this.repository = repository;
    }

    public Produto criarNovo(Produto produto) {
        return repository.save(produto);
    }

    public Produto editarProduto(Integer id, Produto produto) {
        Produto existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não existe no banco de dados com id: " + id));

        existente.setId(produto.getId());
        existente.setValor(produto.getValor());
        existente.setNome(produto.getNome());
        existente.setValor(produto.getValor());
        existente.setDescricao(produto.getDescricao());

        return repository.save(existente);
    }

    public List<Produto> listarProduto(String nome) {
        if(nome == null || nome.trim().equals("")) {
            return repository.findAll();
        }
        return repository.buscarProdutoPeloNome("%" + nome + "%");
//        return repository.findAllByNomeIsLike(nome);
    }
}
