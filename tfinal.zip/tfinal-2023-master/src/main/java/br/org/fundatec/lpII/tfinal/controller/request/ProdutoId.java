package br.org.fundatec.lpII.tfinal.controller.request;

import lombok.Data;

@Data
public class ProdutoId {
    private Integer idProduto;
}
