package br.org.fundatec.lpII.tfinal.controller.request;

public enum FormaPagamento {
    CARTAO,
    BOLETO,
    PIX
}
