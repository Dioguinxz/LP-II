package br.org.fundatec.lpII.tfinal.repository;

public interface EnderecoRepository {

}
