package br.org.fundatec.lpII.tfinal.model;

import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;

@Entity
@Data
@Builder
public class Produto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private Integer valor;

    @Column(length = 100)
    private String nome;

    @Column(length = 100)
    private String descricao;




}
